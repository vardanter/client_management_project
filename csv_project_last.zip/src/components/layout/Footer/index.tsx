export default function Footer() {
    return <footer className="px-2 py-4 text-center bg-slate-400 border-t border-t-gray-50">&copy;2024</footer>
}