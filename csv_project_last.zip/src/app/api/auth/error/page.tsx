export default function ApiauthError() {
    return <div>Error</div>
}