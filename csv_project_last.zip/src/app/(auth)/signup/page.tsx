import SignupForm from "@/components/auth/signup";

export default function SignupPage() {
    return <SignupForm />
}