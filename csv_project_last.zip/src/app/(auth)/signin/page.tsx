import SigninForm from "@/components/auth/Login";

export default function SigninPage() {
    return <SigninForm />
}