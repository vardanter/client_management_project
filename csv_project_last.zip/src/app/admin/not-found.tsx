export default function NotFoundPage() {
    return (
        <div className="flex flex-col items-center justify-center h-full min-h-96">
            <div className="text-9xl">404</div>
            <div className="text-xl">Страница не найдена</div>
        </div>
    )
}