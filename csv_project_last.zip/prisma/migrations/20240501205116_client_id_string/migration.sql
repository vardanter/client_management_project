-- AlterTable
ALTER TABLE "Client" ADD COLUMN "user_id_string" TEXT;
